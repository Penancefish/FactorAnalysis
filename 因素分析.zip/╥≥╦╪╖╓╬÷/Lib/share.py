class SI:
    mainWin = None
    analysisWin = None
    pearsonWin = None
    baseTable = None
    baseTable_init = False
    analysis_table = None