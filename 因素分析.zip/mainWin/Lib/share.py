class SI:
    mainWin = None
    baseTable = None
    baseTable_init = False
    analysis_table = None
    pearson_table = None
    regression_table = None
